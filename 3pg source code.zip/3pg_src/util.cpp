/*
All source code remains the property and copyright of CSIRO. 

CSIRO accepts no responsibility for the use of 3PG(S) or of the model 3-PG in
the form supplied or as subsequently modified by third parties. CSIRO disclaims
liability for all losses, damages and costs incurred by any person as a result
of relying on this software. 
Use of this software assumes agreement to this condition of use
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#ifdef WIN32
#define strncasecmp strnicmp
#endif

//--------------------------------------------------------------------------

char *strcpyTrim(char *s, char *ct)
{
  // Copy ct to s, plus trim leading and trailing white space. 
  int i;
  char *start, *end, *cp;

  if (ct == NULL) {
    s[0] = '\0';
    return NULL;
  }

  // Trim the id string of leading whitespace.  
  for (start = ct; isspace(*start); start++)
    ;
  
  // Was the whole string whitespace. 
  if (*start == '\0') {
    s[0] = '\0';
    return s;
  }

  // Copy it. 
  // Trim trailing whitespace. 
  for (end = start; *end != '\0'; end++)
    ;
  end--;
  if (isspace(*end)) {
    for ( ; isspace(*end); end--)
      ;
  }
  end++;
  *end = '\0';

  // Copy 
  for (i=0, cp = start; cp <= end; cp++, i++)
    s[i] = *cp;
  return s;
}

//--------------------------------------------------------------------------

void logAndExit(FILE *logfp, char *outstr)
{
  fprintf(logfp, outstr);
  fprintf(stderr, outstr);
  exit(1);
}

//--------------------------------------------------------------------------

void logAndPrint(FILE *logfp, char *outstr)
{
  fprintf(logfp, outstr);
  fprintf(stderr, outstr);
}

//--------------------------------------------------------------------------
void logOnly(FILE *logfp, char *outstr)
{
  fprintf(logfp, outstr);
}

//--------------------------------------------------------------------------

bool namesMatch(char *n1, char *n2)
{
  // Basically strcmp, but we compare length also so that substrings don't 
  // match. 
  int l1, l2; 

  l1 = strlen(n1);
  l2 = strlen(n2);
  if (l1 != l2)
    return false;
  if (strncasecmp(n1, n2, l1) == 0)
    return true;
  else
    return false;
}

//--------------------------------------------------------------------------
