// MYDate.h: interface for the MYDate class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYDATE_H__F5D994A0_4E0E_4A44_BF96_8FD567785653__INCLUDED_)
#define AFX_MYDATE_H__F5D994A0_4E0E_4A44_BF96_8FD567785653__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class MYDate  
{
public:
	MYDate();
	virtual ~MYDate();

	int mon; 
	int year; 

};

#endif // !defined(AFX_MYDATE_H__F5D994A0_4E0E_4A44_BF96_8FD567785653__INCLUDED_)
