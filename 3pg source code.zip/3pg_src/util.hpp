// Utility string and log functions. 

char *strcpyTrim(char *s, char *ct);
void logAndExit(FILE *logfp, char *outstr);
void logAndPrint(FILE *logfp, char *outstr);
void logOnly(FILE *logfp, char *outstr);
bool namesMatch(char *n1, char *n2);

