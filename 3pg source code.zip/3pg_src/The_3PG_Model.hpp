// 3PG model run routine.
#include "Data_io.hpp"

void runTreeModel( MYDate spMinMY, MYDate spMaxMY, bool spatial, long cellIndex ); 
